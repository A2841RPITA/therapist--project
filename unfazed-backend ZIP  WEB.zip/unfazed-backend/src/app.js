
const express = require("express");
const cors = require("cors");

const app = express();

// Import routes
const appointmentRoutes = require("./routes/appointmentRoutes");
const clientRoutes = require("./routes/clientRoutes");
const authRoutes = require("./routes/authRoutes");
const availabilityRoutes = require("./routes/availabilityRoutes");
const sessionNoteRoutes = require("./routes/sessionNoteRoutes");
const paymentRoutes = require("./routes/paymentRoutes");

// Authentication middleware
const authenticateToken = require("./middleware/authMiddleware");

app.use(cors());
app.use(express.json());

// Public API health check
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Unfazed API is running",
  });
});

app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    message: "Backend is working correctly",
  });
});

// Public routes
app.use("/api/auth", authRoutes);

// Protected routes
app.use("/api/appointments", authenticateToken, appointmentRoutes);
app.use("/api/clients", authenticateToken, clientRoutes);
app.use("/api/availability", authenticateToken, availabilityRoutes);
app.use("/api/session-notes", authenticateToken, sessionNoteRoutes);
app.use("/api/payments", authenticateToken, paymentRoutes);

module.exports = app;
